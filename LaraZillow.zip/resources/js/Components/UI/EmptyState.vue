<template>
    <Box>
        <div class="w-full font-medium text-gray-500 text-center">
            <slot />
        </div>
    </Box>
</template>

<script setup>
import Box from '@/Components/UI/Box.vue'
</script>