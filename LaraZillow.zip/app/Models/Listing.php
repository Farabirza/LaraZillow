<?php

namespace App\Models;

use App\Traits\GenerateUuid;

use App\Models\Listing;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;

class Listing extends Model
{
    use HasFactory, SoftDeletes, GenerateUuid;
    protected $guarded = [ 'id' ];
    protected $sortable = ['price', 'created_at'];

    protected function owner() {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function images() {
        return $this->hasMany(ListingImage::class);
    }
    public function scopeMostRecent(Builder $query): Builder
    {
        return $query->orderByDesc('created_at');
    }
    public function scopeAvailableOnly(Builder $query)
    {
        // return $query->doesntHave('offers')
        // ->orWhereHas('offers', fn(Builder $query) => $query->whereNull('accepted_at')->whereNull('rejected_at'));
        return $query->whereNull('sold_at');
    }
    public function scopeFilter(Builder $query, array $filters): Builder
    {
        return $query
        ->when(
            $filters['priceFrom'] ?? false,
            fn ($query, $value) => $query->where('price', '>=', $value)
        )
        ->when(
            $filters['priceTo'] ?? false,
            fn ($query, $value) => $query->where('price', '<=', $value)
        )
        ->when(
            $filters['beds'] ?? false,
            fn ($query, $value) => $query->where('beds', (int)$value < 6 ? '=' : '>=', $value)
        )
        ->when(
            $filters['baths'] ?? false,
            fn ($query, $value) => $query->where('baths', (int)$value < 6 ? '=' : '>=', $value)
        )
        ->when(
            $filters['areaFrom'] ?? false,
            fn ($query, $value) => $query->where('area', '>=', $value)
        )
        ->when(
            $filters['areaTo'] ?? false,
            fn ($query, $value) => $query->where('area', '<=', $value)
        )
        ->when(
            $filters['deleted'] ?? false,
            fn ($query, $value) => $query->withTrashed()
        )
        ->when(
            $filters['by'] ?? false,
            fn ($query, $value) => in_array($value, $this->sortable) ? $query->orderBy($value, $filters['order'] ?? 'desc') : $query
        );
    }
    public function offers()
    {
        return $this->hasMany(Offer::class);
    }
}
