<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Laravel Vuejs Intertia\LaraZillow\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>